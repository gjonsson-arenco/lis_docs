# Exportación de chat de WhatsApp: +54 9 3764 57-0196
Fecha de exportación: 17 de noviembre de 2026 a las 13:28

---

## 30 de septiembre de 2026

[14:22] **+54 9 3764 57-0196:** Buenas Gonzalo, soy Alejandro de ConSalud

[14:22] **+54 9 3764 57-0196:** Entre nosotros estaremos viendo el tema de la integración con las API

[14:31] **+54 9 3764 57-0196:** [Documento] guia-api-validacion-afiliado.pdf

[14:35] **+54 9 3764 57-0196:** [Imagen]

[14:37] **+54 9 3764 57-0196:** Por lo pronto solamente tenes ese endpoint de seguridad para obtener el token de seguridad y el endpoint que valida la afiliacion de la persona

[14:37] **+54 9 3764 57-0196:** Como para probar por ahora, apenas vaya teniendo lo demas te paso como corresponde y al terminar te actualizo bien la guia de uso cosa de que te quede bien documentado todo

[15:53] __Los mensajes y las llamadas están cifrados de extremo a extremo. Nadie fuera de este chat, ni siquiera WhatsApp, puede leerlos ni escucharlos. Toca para obtener más información.__

[15:53] __Recibiste un mensaje en el teléfono, pero no es compatible con la versión que tienes de WhatsApp Web.__

[15:53] **Tú:** Hola Alejandro, dale.
Hoy lo probamos.

[17:10] **Tú:** [Imagen] Bien, ya lo tenemos funcionando.

[17:11] **Tú:** Tendras DNIs para probar: un caso de un socio activo, otro de un socio con deuda, o algun tipo de rechazo que lo haga no elegible.

Gracias

[17:11] **+54 9 3764 57-0196:** Buenas dale mañana veo de pasarte todo, salgo del laburo a las 16, por eso

---

## 1 de octubre de 2026

[15:36] **+54 9 3764 57-0196:** Buenas gonzalo ! hice unos cambios hoy en la api, estuve hablando con sergio y tenemos un par de cosas mas a determinar pero por ahora quedó en esto

[15:40] **+54 9 3764 57-0196:** Vamos a tener 3 respuestas: 200 con los datos del afiliado cuando es un afiliado valido, 404 cuando no se encuentra al afiliado (no tiene afiliacion o se escribió mal el dni), y por ultimo 403 que sería cuando es un afiliado pero no accede por distintos motivos (el motivo vendra en el mensaje)

[15:40] **+54 9 3764 57-0196:** [
    {
        "accede": "1",
        "documento": "DNI - 40173783",
        "numero_afiliado": "40173783",
        "secuencia": "0",
        "nombre_completo": "CARUSO ALEJANDRO RENE",
        "fecha_nacimiento": "1997-01-29",
        "convenio_vigente": "30   - Prestadores Sanatoriales S.A.",
        "plan_vigente": "0125 - PSSA 0125                     "
    }
]

[15:40] **+54 9 3764 57-0196:** Ese es un ejemplo de un afiliado activo (soy yo)

[15:40] **Tú:** Ok, pero va alguna descripción para levantar?

[15:40] **Tú:** En el response

[15:41] **+54 9 3764 57-0196:** en el caso de que haya un motivo por el cual no accede, si

[15:41] **+54 9 3764 57-0196:** en el caso del 404 no es necesaria, pero hay por las dudas

[15:41] **Tú:** Ok

[15:42] **+54 9 3764 57-0196:** 35487431    este es un dni de un afiliado que ya fue dado de baja

[15:42] **Tú:** Necesito :

Variedad de DNI para validar los casos 


Listado de prácticas habilitadas para transaccionar , código y descripción

[15:42] **Tú:**
> _+54 9 3764 57-0196: 35487431    este es un dni de un afiliado que ya fue dado de baja_
Genial!

[15:42] **+54 9 3764 57-0196:** {
    "mensaje": "Afiliación dada de baja el 31/03/2023, cualquier duda ir a boca de expendio o consultar por mensaje al WhatsApp 3764208589"
}

[15:42] **+54 9 3764 57-0196:** Ese es un ejemplo del mensaje, lo pensamos como para que lo muestres al operador y ya tengan la instruccion que darle al afiliado

[15:42] **+54 9 3764 57-0196:** Asi no tienen que andar preguntando

[15:42] **Tú:** Claro, yo muestro eso

[15:43] **Tú:** No interpreto nada

[15:43] **+54 9 3764 57-0196:** si la respuesta es uin 403, si

[15:43] **+54 9 3764 57-0196:** Podes confiar que eso va a tener el visto bueno de sergio

[15:43] **+54 9 3764 57-0196:** Dejamos esto asi porque van a surgir muchos casos de " no se le permite acceder por X motivos "

[15:44] **+54 9 3764 57-0196:** Englobamos todo, y cambiamos el mensaje acorde a la situacion

[15:44] **Tú:** Ok

[15:44] **+54 9 3764 57-0196:** Eso para el proceso de validacion, basicamente estamos diciendo "este afiliado puede", "este no", "este no existe"

[15:44] **Tú:** Eso ya está implementado?

[15:45] **+54 9 3764 57-0196:** Si, deberias tener esa respuesta en este momento

[15:45] **Tú:** Ok

[15:45] **Tú:** Se prueba hoy

[15:45] **+54 9 3764 57-0196:** Ahora para el resto de los procesos estamos terminando de armar y apenas tengamos vamos pasando pero te explico como seria , a ver si me puedo hacer entender

[15:45] **Tú:** [Mensaje de voz]

[15:46] **+54 9 3764 57-0196:** Tenes el nomenclador para eso ?

[15:46] **+54 9 3764 57-0196:** O queres que te pase el listado compleeeto de codigos

[15:47] **Tú:** [Mensaje de voz]

[15:47] **Tú:**
> _+54 9 3764 57-0196: O queres que te pase el listado compleeeto de codigos_
Eso

[15:47] **+54 9 3764 57-0196:** Aah te toca hacer equivalencias, dale ahi me fijo como te los paso

[15:50] **+54 9 3764 57-0196:** [Documento] nomenclador-consalud-bioquimicos.txt

[15:50] **+54 9 3764 57-0196:** Fijate si te sirve asi

[15:53] **+54 9 3764 57-0196:** Mientras tanto te cuento. Vamos a tener un endpoint donde nos mandarias la lista de codigos y el afiliado. Pero no todos nuestros codigos van a poder "autorizarse" automaticamente, algunos si estan libres, pero otros tienen que pasar por un proceso de autorizacion. En los casos de que estén todos ok y puedan hacerse ahi mismo todo, te dariamos los datos de la orden (que tendria esos codigos cargados) y un endpoint que te sirva para confirmar la atencion.

[15:54] **Tú:** Me devolves un estado por práctica ?

[15:55] **+54 9 3764 57-0196:**
> _Tú: Me devolves un estado por práctica ?_
Te devolveria una confirmacion general del conjunto de codigos completo

[15:55] **Tú:** Y si uno falla, fallan todos ?

[15:56] **+54 9 3764 57-0196:** Para eso tendriamos otro endpoint que reciba los mismos parametros pero solamente te confirme si esos codigos irian autorizados automaticamente, o si al menos uno requiere auditoria, en ese caso la orden entera va para auditoria, me explico ?

[15:56] **Tú:** [Mensaje de voz]

[15:57] **+54 9 3764 57-0196:** En este momento funciona asi, no quiere decir que rechazamos el pedido, solo que un auditor lo controla y le da el "ok"

[15:58] **Tú:** [Mensaje de voz]

[15:58] **+54 9 3764 57-0196:** Caundo un pedido va para auditoria, a ustedes en lugar de salirles la orden como respuesta, les sale un numero de autorizacion que es el mismo que veria el afiliado desde la app de consalud

[15:58] **Tú:** Ok

[15:59] **+54 9 3764 57-0196:**
> _Tú: Mensaje de voz_
Suena hermoso, pero deberiamos plantearlo a ver si nos permiten hacerlo

[16:00] **Tú:** [Mensaje de voz]

[16:00] **+54 9 3764 57-0196:** Estaria bueno poder hacer algo por ese estilo

[16:00] **+54 9 3764 57-0196:** En el proceso de confirmacion normal si, va a haber un token que haya que pedirle al paciente

[16:01] **+54 9 3764 57-0196:** Tambien hay algunas excepciones (planes premium digamos) que se podrian saltear lo del token y autorizar derechito

[16:02] **Tú:** [Mensaje de voz]

[16:02] **+54 9 3764 57-0196:** Eso mas adelante te confirmare mejor

[16:02] **+54 9 3764 57-0196:**
> _Tú: Mensaje de voz_
Dale buenisimo, mañana te especifico bien todo de los demas endpoints  que ya me estan por cerrar al oficina jajaj

[16:03] **Tú:** Listo

[16:03] **+54 9 3764 57-0196:** la documentacion te la voy a tener que actualizar cuando terminemos

[16:03] **+54 9 3764 57-0196:** porque con lo que te pase hoy ya se le agregaron cosas a la que te di el otro dia

[16:08] **+54 9 3764 57-0196:** [Mensaje de voz]

[16:14] **Tú:** [Mensaje de voz]

[16:21] **+54 9 3764 57-0196:** Claaaro, acá 20 requests te harían 20 órdenes distintas

[16:21] **+54 9 3764 57-0196:** Ahí te matan

[16:22] **Tú:** Jajajaj

[16:22] **Tú:** Ok

[16:22] **Tú:** [Mensaje de voz]

[16:23] **+54 9 3764 57-0196:** [Mensaje de voz]

[16:23] **+54 9 3764 57-0196:**
> _Tú: Mensaje de voz_
No suena mal te digo

[16:23] **+54 9 3764 57-0196:** Cualquier cosa yo no dije nada jajajaj

[16:24] **+54 9 3764 57-0196:** [Mensaje de voz]

[16:24] **+54 9 3764 57-0196:** [Mensaje de voz]

[16:29] **Tú:** Clarisimo

---

## 2 de octubre de 2026

[15:24] **+54 9 3764 57-0196:** Como andas

[15:24] **+54 9 3764 57-0196:** Hoy tocó dia de reuniones asi que se avanzó un poco no mas

[15:25] **+54 9 3764 57-0196:** Peeeeero, parece que consegui que acepten eso de "partir" el pedido y mandar por un lado los codigos preaprobados y por otro los que van para auditoria

[15:26] **+54 9 3764 57-0196:** Por lo pronto te dejo los 2 nuevos endpoints

[15:26] **+54 9 3764 57-0196:** https://encasa.consalud.com.ar/api/codigos/verificar  y   https://encasa.consalud.com.ar/api/codigos/autorizar

[15:27] **+54 9 3764 57-0196:** Ambos post

[15:27] **+54 9 3764 57-0196:** todo lo mismo, con el token que pedias

[15:27] **+54 9 3764 57-0196:** El body para ambos endpoint es el mismo

[15:27] **+54 9 3764 57-0196:** {
  "dni": "40173783",
  "codigos": [
    { "codigo": "660001", "cantidad": 1 },
    { "codigo": "660711", "cantidad": 1 },
    { "codigo": "660412", "cantidad": 1 }
  ]
}

[15:27] **+54 9 3764 57-0196:** el dni del afiliado y la lista de codigos con sus cantidades respectivas

[15:28] **+54 9 3764 57-0196:** el primer endpoint sirve para chequear si esos codigos irian a auditoria o si se aprueban directamente, y para saber el coseguro que se les debe cobrar

[15:29] **+54 9 3764 57-0196:** responde asi 
{
    "autorizado": 1,
    "respuesta": "ok",
    "coseguro": 0.0
}

[15:29] **+54 9 3764 57-0196:** {
    "autorizado": 0,
    "respuesta": "Requiere auditoria",
    "coseguro": 0.0
}

[15:30] **+54 9 3764 57-0196:** Ese endpoint es el que me aprobaron hoy para devolver tambien la lista de codigos y cuales se autorizan automaticamente y cuales no

[15:32] **+54 9 3764 57-0196:** Asi que la semana que viene voy a agregarle un campo a esa respuesta (ya que esa respuesta es para todos los codigos en conjunto) en el que venga la lista de codigo y con sus autorizado en 1 y 0

[15:32] **+54 9 3764 57-0196:** Ahi vas a poder hacer la separacion de esos codigos e invocar al segundo endpoint, que seria "autorizarlos" o "mandarlos a auditoria" dependiendo

[15:33] **+54 9 3764 57-0196:**
> _+54 9 3764 57-0196: {
  "dni": "40173783",
  "codigos": [
    { "codigo": "660001", "cantidad": 1 },
    { "codigo": "660711", "cantidad": 1 },
    { "codigo": "660412", "cantidad": 1 }
  ]
}_
El segundo endpoint se invoca exactamente igual que el primero como en este mensaje

[15:34] **+54 9 3764 57-0196:** En el segundo endpoint no se por que me dejaron comentada la accion en el codigo, asi que voy a estar viendo eso la semana que viene con sergio, pero por ahora te hardcodeé la respuesta con un pedido autorizado (simulando el funcionamiento de cuando se autoriza todo)

[15:35] **+54 9 3764 57-0196:** La respuesta queda asi:
{
    "mensaje": "ok",
    "prefijo": "VC",
    "numero_orden": 8944
}

[15:36] **+54 9 3764 57-0196:** Esa seria la orden VC-8944 para nosotros, en este caso un pedido mio autorizado

[15:37] **+54 9 3764 57-0196:** La semana que viene le damos bien la funcionalidad que corresponde a ambos endpoints y te estare avisando todo. Tambien los endpoints faltantes que te estoy debiendo

[15:38] **+54 9 3764 57-0196:** Disculpa la cantidad de mensajes, era para que quede bien registrado y no olvidarme, ya que fue un dia de locos

[15:40] **Tú:** Listo. Se ve...

[15:41] **Tú:** Lo analizo y probamos.

---

## 6 de octubre de 2026

[15:31] **Tú:** Cómo andas?
Ya estoy al día con todo, cuando tenagas listo los endpoints probamos

[15:39] **+54 9 3764 57-0196:** Buenas Gonzalo ! todo bien y vos

[15:40] **+54 9 3764 57-0196:** Perfecto, aca andamos con unos temitas que nos surgieron, apenas vayamos teniendo todo te voy avisando y pasando para tus pruebas

---

## 19 de octubre de 2026

[13:23] **+54 9 3764 57-0196:** Gonzalo como estas ?

[13:26] **+54 9 3764 57-0196:** Te consulto, ustedes tienen una lista de los profesionales de consalud? ya que nos dieron la norma de que solo vamos a cubrir pedidos que tengan como medico solicitante un prestador de Consalud, y eso lo chequeariamos con los endpoint de verificacion de los codigos (para verificar que es de hecho un prestador de consalud) y con el que graba el pedido (o crea la solicitud de autorizacion) para dejarlo plasmado de forma real. El chequeo se haria mediante el CUIT del prestador

[13:26] **+54 9 3764 57-0196:** Si no dispones de la lista, puedo armarte un endpoint que puedas ejecutar para traer la lista completa y actualizada, asi les das la opcion de elegir solamente entre los que nosotros tenemos como activos

[14:10] **Tú:** Podemos mandar el profesional

[14:10] **Tú:** Pero usamos nuestros propios catálogos

[14:10] **Tú:** El laboratorio los va a mapear, me sirve el enfpoint

[14:12] **+54 9 3764 57-0196:**
> _Tú: El laboratorio los va a mapear, me sirve el enfpoint_
Dale, apunto por ese lado. Aviso que como va a ser dinamico lo deberias llamar (quizas una vez al dia eso lo veras vos) para que vayan siendo efectivos los cambios

[14:12] **Tú:** Es que ahí manejamos nuestro propio catálogo

[14:13] **Tú:** Eso lo administran en el lab

[14:14] **Tú:** [Mensaje de voz]

[14:15] **+54 9 3764 57-0196:** Preprado ambas cosas por las dudas, tanto el endpoint como el error de "este prestador no pertenece a consalud" por si hay que avisar la no cobertura

---

## 23 de octubre de 2026

[15:54] **+54 9 3764 57-0196:** Buenas tardes gonzalo !

[15:54] **+54 9 3764 57-0196:** Te dejo la guia completa de como se van a usar los endpoints y el proceso completo

[15:54] **+54 9 3764 57-0196:** [Documento] Guia-utilizacion-API.pdf

[15:55] **+54 9 3764 57-0196:** Aviso por las dudas que todavia no van a estar utilizables los endpoints ya que arrastraron otro desarrollo que estuve haciendo estas semanas, por eso la tardanza

[15:56] **+54 9 3764 57-0196:** Lo mas seguro es que la semana que viene suba los cambios para que ya estén utilizables los mismos. Por lo pronto NO estan subidos a produccion. Su utilizacion no va a cambiar asi que podes ir preparando para consumirlos como aparecen alli

[15:56] **+54 9 3764 57-0196:** Cualquier duda vos decime no mas, no tengo dramas !

[15:57] **+54 9 3764 57-0196:** Obviamente apenas estén subidos los cambios con los endpoints a producción te estaré avisando, cosa de poder probar con mi usuario (el del dni que aparece en la guia)

[16:51] **Tú:** Genial Alejandro,
Voy mirando la guía 
Saludos!

---

## 10 de noviembre de 2026

[11:38] **+54 9 3764 57-0196:** Como estas Gonzalo, mil perdones por la tardanza

[11:38] **+54 9 3764 57-0196:** No te das una idea de todo lo que surgio entre medio

[11:38] **+54 9 3764 57-0196:** Ya estan subidos a produccion los endpoint de la guia

[11:39] **+54 9 3764 57-0196:** Cualquier cosita avisame, gracias por esperarme hasta ahora

[11:54] **Tú:** Cómo andas?
Genial, hago unas pruebas y te cuento

[12:55] **+54 9 3764 57-0196:** Cualquier cosa usa mi usuario para test, si podes usar el endpoint de anular orden para las que se creen mejor, sino reviso cada tanto de todas formas para que todo quede ok

[12:55] **+54 9 3764 57-0196:** Asi de paso tenes un usuario real para testeos
